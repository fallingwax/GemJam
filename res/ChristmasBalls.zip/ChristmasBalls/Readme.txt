Asset license: Creative Commons Attribution v4.0 International
All purchased assets can be used by you in your projects (commercial and free).
Commercial and free use; Attribution not required;


Author: Wenrexa;
Please watch my channel: https://www.youtube.com/channel/UCSPiqZ5-_i45_IyisQ2QvhQ
Twitter: https://twitter.com/wenrexa 
Email: wenrexacorp@gmail.com
Discord server: https://discord.gg/97semfv
Write in the comments what you want to get and I will draw it. 